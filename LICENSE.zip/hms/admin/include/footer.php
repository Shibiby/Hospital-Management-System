<footer>
			<div class="footer" style="padding-top: 20px; padding-bottom: 10px;">
				<div class="container-fluid text-center">
					&copy; <span class="current-year">2019</span><span class="text-bold text-uppercase"> <a href="mailto:info@mfm.co.ke">MOBICLINIC</a></span>. <span>All rights reserved</span>
				</div>
				
			</div>
		</footer>